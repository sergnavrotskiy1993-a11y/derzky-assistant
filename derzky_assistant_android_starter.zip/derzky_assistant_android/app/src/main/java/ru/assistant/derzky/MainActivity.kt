package ru.assistant.derzky

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AssistantScreen() }
    }
}

@Composable
fun AssistantScreen() {
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("Ассистент" to "Ну что, на связи. Пока это стартовый экран — подключим голос и поиск следующим этапом.") }

    MaterialTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(title = { Text("Дерзкий ассистент 😏") })
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Напиши сообщение…") },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 4
                    )
                    IconButton(onClick = { /* Подключим ElevenLabs после настройки безопасного backend */ }) {
                        Icon(Icons.Default.Mic, contentDescription = "Голос")
                    }
                    IconButton(onClick = {
                        if (input.isNotBlank()) {
                            messages.add("Ты" to input.trim())
                            input = ""
                        }
                    }) {
                        Icon(Icons.Default.Send, contentDescription = "Отправить")
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { (who, message) ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(who, style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(4.dp))
                            Text(message)
                        }
                    }
                }
            }
        }
    }
}
